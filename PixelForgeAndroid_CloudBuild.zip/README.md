# PixelForge Android — starter project

Original Android photo editor starter written from scratch.

## Current prototype
- Import an image through Android's image picker
- Canvas display and finger drawing
- Brush and eraser tools
- Basic pan tool
- Undo last stroke
- Export merged image as PNG to Pictures/PixelForge

## Build APK from a phone using GitHub Actions
1. Extract this ZIP on your phone.
2. Create a GitHub repository.
3. Upload the extracted project contents, including the hidden `.github/workflows/build.yml` file.
4. Open the repository's Actions tab.
5. If prompted, enable Actions, then run `Build PixelForge APK` using `Run workflow`.
6. When the run finishes successfully, open it and download the `PixelForge-debug-apk` artifact.
7. Extract the downloaded artifact ZIP and install the APK.

The workflow uses Java 17 and Gradle 8.9 on a GitHub-hosted runner.

## Limitations
This is an initial prototype, not a Photoshop-equivalent product. It does not yet have real layer management, masks, selection tools, multi-touch zoom, PSD support, advanced filters, or production testing. Review and test on a device before distributing.
