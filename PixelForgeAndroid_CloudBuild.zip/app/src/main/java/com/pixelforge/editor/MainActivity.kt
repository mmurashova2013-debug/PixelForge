package com.pixelforge.editor

import android.app.Activity
import android.content.ContentValues
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var canvasView: EditorCanvas
    private lateinit var status: TextView
    private val undoStack = ArrayDeque<Bitmap>()
    private var currentTool = EditorCanvas.Tool.BRUSH

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bmp != null) {
                    canvasView.setImage(bmp)
                    undoStack.clear()
                    status.text = "Фото загружено · ${bmp.width} × ${bmp.height}"
                } else toast("Не удалось открыть изображение")
            } catch (_: Exception) { toast("Не удалось открыть изображение") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17,19,24)
        window.navigationBarColor = Color.rgb(17,19,24)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17,19,24))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 12, 16, 12)
        }
        top.addView(TextView(this).apply {
            text = "PIXELFORGE"
            textSize = 18f
            setTextColor(Color.rgb(183,255,90))
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionButton("Открыть") { imagePicker.launch("image/*") })
        top.addView(actionButton("Экспорт") { exportImage() })
        page.addView(top)

        canvasView = EditorCanvas(this)
        page.addView(canvasView, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            text = "Откройте фото или рисуйте на пустом холсте"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(16, 8, 16, 8)
        }
        page.addView(status)

        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(6, 8, 6, 8)
        }
        listOf(
            "Кисть" to EditorCanvas.Tool.BRUSH,
            "Ластик" to EditorCanvas.Tool.ERASER,
            "Переместить" to EditorCanvas.Tool.MOVE
        ).forEach { (label, tool) ->
            val b = actionButton(label) {
                currentTool = tool
                canvasView.tool = tool
                status.text = "Инструмент: $label"
            }
            tools.addView(b, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(3,0,3,0) })
        }
        tools.addView(actionButton("↶") {
            canvasView.undo()
            status.text = "Последнее действие отменено"
        })
        page.addView(tools)
        val hint = TextView(this).apply {
            text = "Совет: откройте изображение, затем рисуйте пальцем. Экспорт сохраняет PNG."
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(10, 0, 10, 12)
        }
        page.addView(hint)
        setContentView(page)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(42,46,56))
        setOnClickListener { action() }
    }

    private fun exportImage() {
        val bmp = canvasView.exportBitmap()
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "PixelForge_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PixelForge")
        }
        try {
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                toast("Сохранено в Pictures/PixelForge")
            } else toast("Не удалось сохранить файл")
        } catch (_: Exception) { toast("Ошибка экспорта") }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

class EditorCanvas(context: android.content.Context) : View(context) {
    enum class Tool { BRUSH, ERASER, MOVE }
    var tool = Tool.BRUSH
    private var baseBitmap: Bitmap? = null
    private var drawingBitmap: Bitmap? = null
    private var drawCanvas: Canvas? = null
    private var scale = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moving = false
    private var brushSize = 12f
    private val brushColor = Color.rgb(183,255,90)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = brushSize
        color = brushColor
    }
    private val checker = Paint()
    private val undo = ArrayDeque<Bitmap>()

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    fun setImage(bitmap: Bitmap) {
        val maxSide = 2400
        val ratio = min(1f, maxSide.toFloat() / max(bitmap.width, bitmap.height))
        val safe = if (ratio < 1f) Bitmap.createScaledBitmap(bitmap, (bitmap.width*ratio).toInt(), (bitmap.height*ratio).toInt(), true) else bitmap.copy(Bitmap.Config.ARGB_8888, true)
        baseBitmap = safe.copy(Bitmap.Config.ARGB_8888, true)
        drawingBitmap = Bitmap.createBitmap(safe.width, safe.height, Bitmap.Config.ARGB_8888)
        drawCanvas = Canvas(drawingBitmap!!)
        undo.clear()
        fitImage()
        invalidate()
    }

    private fun fitImage() {
        val bmp = baseBitmap ?: return
        scale = min(width.toFloat()/bmp.width, height.toFloat()/bmp.height).coerceAtMost(1f)
        if (scale <= 0f) scale = 1f
        offsetX = (width - bmp.width*scale)/2f
        offsetY = (height - bmp.height*scale)/2f
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) { if (baseBitmap != null) fitImage() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(28,30,37))
        val gridPaint = Paint().apply { color = Color.rgb(37,40,48); strokeWidth = 1f }
        var x = 0f
        while (x < width) { canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint); x += 32f }
        var y = 0f
        while (y < height) { canvas.drawLine(0f, y, width.toFloat(), y, gridPaint); y += 32f }
        val bmp = baseBitmap
        if (bmp == null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.LTGRAY; textSize = 17f; textAlign = Paint.Align.CENTER }
            canvas.drawText("PIXELFORGE", width/2f, height/2f - 10f, p)
            p.textSize = 12f; p.color = Color.GRAY
            canvas.drawText("Откройте фотографию сверху", width/2f, height/2f + 18f, p)
            return
        }
        val save = canvas.save()
        canvas.translate(offsetX, offsetY)
        canvas.scale(scale, scale)
        canvas.drawBitmap(bmp, 0f, 0f, paint)
        drawingBitmap?.let { canvas.drawBitmap(it, 0f, 0f, paint) }
        canvas.restoreToCount(save)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val bx = (event.x - offsetX) / scale
        val by = (event.y - offsetY) / scale
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x; lastY = event.y
                if (tool == Tool.MOVE) { moving = true; return true }
                snapshot()
                if (baseBitmap == null) {
                    if (drawingBitmap == null) {
                        drawingBitmap = Bitmap.createBitmap(max(1,width), max(1,height), Bitmap.Config.ARGB_8888)
                        drawCanvas = Canvas(drawingBitmap!!)
                        offsetX = 0f; offsetY = 0f; scale = 1f
                    }
                }
                paint.strokeWidth = brushSize / scale
                paint.color = if (tool == Tool.ERASER) Color.TRANSPARENT else brushColor
                paint.xfermode = if (tool == Tool.ERASER) PorterDuffXfermode(PorterDuff.Mode.CLEAR) else null
                drawCanvas?.drawPoint(bx, by, paint)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (moving && tool == Tool.MOVE) {
                    offsetX += event.x - lastX; offsetY += event.y - lastY
                    lastX = event.x; lastY = event.y
                    invalidate(); return true
                }
                drawCanvas?.drawLine(lastXImage(), lastYImage(), bx, by, paint)
                lastX = event.x; lastY = event.y
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { moving = false; paint.xfermode = null; return true }
        }
        return true
    }

    private fun lastXImage() = (lastX - offsetX) / scale
    private fun lastYImage() = (lastY - offsetY) / scale

    private fun snapshot() {
        drawingBitmap?.let {
            undo.addLast(it.copy(Bitmap.Config.ARGB_8888, true))
            if (undo.size > 20) undo.removeFirst().recycle()
        }
    }

    fun undo() {
        if (undo.isNotEmpty()) {
            drawingBitmap?.recycle()
            drawingBitmap = undo.removeLast()
            drawCanvas = Canvas(drawingBitmap!!)
            invalidate()
        }
    }

    fun exportBitmap(): Bitmap {
        val base = baseBitmap
        val drawing = drawingBitmap
        if (base == null) return drawing?.copy(Bitmap.Config.ARGB_8888, true)
            ?: Bitmap.createBitmap(max(1,width), max(1,height), Bitmap.Config.ARGB_8888)
        val result = base.copy(Bitmap.Config.ARGB_8888, true)
        if (drawing != null) Canvas(result).drawBitmap(drawing, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG))
        return result
    }
}
